const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'yogi*021947',
  database: 'raitha_mitra_db'
});

db.connect((err) => {
  if (err) {
    console.error("❌ MySQL connection error:", err);
  } else {
    console.log("✅ Connected to MySQL database.");
  }
});

// Register route
app.post('/register', (req, res) => {
  const { survey_no, crop_name, market, land_range } = req.body;

  if (!survey_no || !crop_name || !market || !land_range) {
    return res.status(400).json({ message: "❌ All fields are required." });
  }

  // Check for duplicate survey number (case-insensitive)
  const checkQuery = `SELECT * FROM registrations WHERE LOWER(survey_no) = ?`;
  db.query(checkQuery, [survey_no.toLowerCase()], (err, results) => {
    if (err) {
      console.error("❌ Duplication check error:", err);
      return res.status(500).json({ message: "Server error while checking for duplicates." });
    }

    if (results.length > 0) {
      return res.status(409).json({ message: "❌ This survey number is already registered." });
    }

    // Insert new record
    const insertQuery = `
      INSERT INTO registrations (survey_no, crop_name, market, land_range)
      VALUES (?, ?, ?, ?)
    `;
    db.query(insertQuery, [survey_no, crop_name, market, land_range], (err, result) => {
      if (err) {
        console.error("❌ Insert error:", err);
        return res.status(500).json({ message: "Failed to register crop." });
      }

      return res.status(200).json({ message: "✅ Crop registered successfully!" });
    });
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});


// GET GRAPH
// Route to get market data for graph
app.get('/api/market-data', (req, res) => {
  const market = req.query.market;

  if (!market) {
    return res.status(400).json({ message: "Market is required" });
  }

  const query = `
    SELECT crop_name, SUM(land_range) as total_land
    FROM registrations
    WHERE market = ?
    GROUP BY crop_name
  `;

  db.query(query, [market], (err, results) => {
    if (err) {
      console.error("❌ Error fetching market data:", err);
      return res.status(500).json({ message: "Server error" });
    }

const cors = require('cors');
app.use(cors());
    res.json(results);
  });
});
